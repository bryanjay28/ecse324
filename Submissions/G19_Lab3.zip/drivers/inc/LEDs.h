#ifndef __LEDs
#define __LEDs

	extern int read_LEDs_ASM();		//function declarations
	extern int write_LEDs_ASM(int a);	//accepts argument int a 

#endif

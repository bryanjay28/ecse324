#ifndef __AUDIO
#define __AUDIO

    int AUDIO_write_ASM(int data);

#endif
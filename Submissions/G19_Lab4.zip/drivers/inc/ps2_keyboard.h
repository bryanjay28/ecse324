#ifndef __PS2_KEYBOARD
#define __PS2_KEYBOARD

    int read_PS2_data_ASM(char *data);

#endif